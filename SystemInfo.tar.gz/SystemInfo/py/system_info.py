#!/usr/bin/env python
import sys

from lib import gui_tkinter, gui_zenity, gui_console


if '-h' in sys.argv or '--help' in sys.argv:
    print('Usage: system_info.py [options]')
    print('Available options:')
    print('  -h,  --help     Print this message')
    print('  -c,  --console  Do not start GUI')
    print('  -z,  --zenity   Start with zenity GUI even if Tkinter is available.')
    sys.exit(0)


ui_classes = [gui_tkinter.TkinterGui, gui_zenity.ZenityGUI, gui_console.ConsoleGUI]
if '-c' in sys.argv or '--console' in sys.argv:
    ui_classes.remove(gui_tkinter.TkinterGui)
    ui_classes.remove(gui_zenity.ZenityGUI)
elif '-z' in sys.argv or '--zenity' in sys.argv:
    ui_classes.remove(gui_tkinter.TkinterGui)

for c in ui_classes:
    ui = c()
    if ui.is_available():
        ui.run()
        break
