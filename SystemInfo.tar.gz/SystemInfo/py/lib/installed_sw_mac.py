import os
import plistlib
from lib import command_runner


def get_installed_version(plist_data):
    install_date = None
    package_id = None
    version = '-'
    try:
        pl = plistlib.readPlistFromString(plist_data)
        if 'InstallDate' in pl:
            install_date = pl['InstallDate']
        if 'PackageIdentifier' in pl:
            package_id = pl['PackageIdentifier']
        if 'PackageVersion' in pl:
            version = pl['PackageVersion']
    except:
        pass
    if package_id:
        if package_id.endswith('.pkg'):
            package_id = package_id[:-4]
        if install_date:
            package_id = install_date.strftime('[%d-%m-%Y] ') + package_id
    return package_id, version, install_date


def is_known_mw(file_name):
    if not file_name.endswith('.plist'):
        return False
    if 'bit4id' in file_name.lower():
        return True
    if file_name.startswith('org.opensc-project.'):
        return True
    if file_name.startswith('com.charismathics.'):
        return True
    if file_name.startswith('com.cryptovision.'):
        return True
    if file_name.startswith('com.Siemens.cardosapi.'):
        return True
    if file_name.startswith('com.gemalto.'):
        return True
    if file_name.startswith('com.FTSafe.'):
        return True


def find_installed_mw_mac(dir):
    result = []
    for x in os.listdir(dir):
        if is_known_mw(x):
            plist_path = os.path.join(dir, x)
            cmd = command_runner.Command(['plutil', '-convert', 'xml1', '-o', '-', plist_path])
            status = cmd.run()
            if status == 0:
                info = get_installed_version(str(cmd.out))
                if info[0] is None:
                    info = (x, info[1])
                result.append(info)
    result.sort(key=lambda sw: sw[2])
    return result
