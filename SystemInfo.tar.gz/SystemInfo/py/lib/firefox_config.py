import json
import os
import tempfile
import shutil

from lib import command_runner, gui_utils
from lib.os_information import os_info
from lib.nss_pkcs11_db import NssDatabase

try:
    import ConfigParser as ini_parser
except ImportError:
    import configparser as ini_parser


class FirefoxConfig:

    def __init__(self):
        profiles = ini_parser.ConfigParser()
        self.profile_dir = None
        self.dev_edition_profile_dir = None
        self.user = None
        self.system = None
        self.user_dev = None
        self.system_dev = None
        self.nspr_path = None
        self.nss_path = None

        if os_info.is_mac():
            path = os.path.expanduser('~/Library/Application Support/Firefox')
        else:
            path = os.path.expanduser('~/.mozilla/firefox')

        ini_path = os.path.join(path, 'profiles.ini')
        loaded = profiles.read(ini_path)
        if len(loaded) == 0:
            return
        if loaded[0] != ini_path:
            return

        saved_section = None
        for s in profiles.sections():
            try:
                name = profiles.get(s, 'Name')
                if 'dev-edition-default' in name:
                    self.dev_edition_profile_dir = self.find_profile_path(profiles, s, path)
                else:
                    saved_section = s
                default = profiles.get(s, 'Default')
                if default == '1':
                    self.profile_dir = self.find_profile_path(profiles, s, path)
            except ini_parser.NoOptionError:
                pass
        if self.profile_dir is None and saved_section is not None:
            self.profile_dir = self.find_profile_path(profiles, saved_section, path)

        if self.profile_dir:
            self.user, self.system = self.find_extensions(self.profile_dir)
        if self.dev_edition_profile_dir:
            self.user_dev, self.system_dev = self.find_extensions(self.dev_edition_profile_dir)

    @staticmethod
    def find_profile_path(ini, section, path):
        dir_path = ini.get(section, 'Path')
        is_relative = ini.get(section, 'IsRelative')
        if is_relative:
            return os.path.join(path, dir_path)
        else:
            return dir_path

    def is_firefox_found(self):
        return self.profile_dir is not None

    def is_dev_edition_found(self):
        return self.dev_edition_profile_dir is not None

    def get_extensions(self, dev_edition=False):
        if dev_edition:
            return self.user_dev
        return self.user

    def get_extensions_system(self, dev_edition=False):
        if dev_edition:
            return self.system_dev
        return self.system

    def get_pkcs11_modules(self, dev_edition=False):
        try:
            if dev_edition:
                return self.find_pkcs11_modules(self.dev_edition_profile_dir)
            else:
                return self.find_pkcs11_modules(self.profile_dir)
        except Exception as ex:
            return [('Unknown', ex)]

    @staticmethod
    def copy_file(src, dst, file_name):
        src_path = os.path.join(src, file_name)
        if os.path.isfile(src_path):
            dst_path = os.path.join(dst, file_name)
            shutil.copyfile(src_path, dst_path)

    def find_pkcs11_modules(self, profile_dir):
        if profile_dir is None:
            return [('Unknown', 'No profile directory')]
        nss_db_dir = tempfile.mkdtemp()
        sql_db = False
        if os.path.isfile(os.path.join(profile_dir, 'pkcs11.txt')):
            sql_db = True
            self.copy_file(profile_dir, nss_db_dir, 'cert9.db')
            self.copy_file(profile_dir, nss_db_dir, 'key4.db')
            self.copy_file(profile_dir, nss_db_dir, 'pkcs11.txt')
        else:
            self.copy_file(profile_dir, nss_db_dir, 'cert8.db')
            self.copy_file(profile_dir, nss_db_dir, 'key3.db')
            self.copy_file(profile_dir, nss_db_dir, 'secmod.db')

        if sql_db:
            nss_db = NssDatabase('sql:' + nss_db_dir)
        else:
            nss_db = NssDatabase(nss_db_dir)
        if not os_info.is_mac():
            ok, result = nss_db.get_pkcs11_modules_db_mp()
        else:
            ok = False

        error = '-'
        if not ok:
            result = []
            env = os.environ
            firefox_lib_dir = nss_db.firefox_install_dir
            if firefox_lib_dir is not None:
                if os_info.is_mac():
                    env['DYLD_LIBRARY_PATH'] = firefox_lib_dir
                else:
                    env['LD_LIBRARY_PATH'] = firefox_lib_dir
            else:
                firefox_lib_dir = '-'
            if os_info.is_mac():
                suffix = ''
            else:
                suffix = '-' + os_info.arch()
            script_path = os.path.join(gui_utils.get_lib_dir(), 'nss-list-pkcs11' + suffix)
            exe = command_runner.Command([script_path, firefox_lib_dir, nss_db_dir])
            status = exe.run(timeout=15, environment=env)
            if status == 0:
                ok = True
                if exe.out is not None and len(exe.out) > 0:
                    for line in exe.out.split('\n'):
                        m = line.split('\t')
                        if len(m) > 1:
                            result.append((m[0], m[1]))
            else:
                error = 'Internal error [' + str(status) + ']'

        shutil.rmtree(nss_db_dir)
        if ok:
            return result
        return [('Unknown', error)]

    @staticmethod
    def find_extensions(profile_dir):
        user = []
        system = []
        user_disabled = []
        system_disabled = []
        ext_list = os.path.join(profile_dir, 'extensions.json')
        try:
            ext_file = open(ext_list, 'r')
        except EnvironmentError:  # Parent of OSError and IOError before Python 3.3, or alias of OSError after
            pass
        else:
            with ext_file:
                extensions = json.load(ext_file)
                try:
                    for e in extensions['addons']:
                        name = e['defaultLocale']['name']
                        if 'signText' not in name and 'InfoNotary' not in name:
                            continue
                        version = e['version']
                        ext_type = e['type']
                        loc = e['location']
                        if loc == 'app-profile':
                            is_user = True
                        else:
                            is_user = False
                        if ext_type != 'extension' and ext_type != 'webextension':
                            continue
                        if e['active']:
                            if is_user:
                                user.append((name, version))
                            else:
                                system.append((name, version))
                        else:
                            if is_user:
                                user_disabled.append((name + ' (disabled)', version))
                            else:
                                system_disabled.append((name + ' (disabled)', version))
                except KeyError:
                    pass
        user.extend(user_disabled)
        system.extend(system_disabled)
        return user, system
