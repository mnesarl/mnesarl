import sys
import platform
try:
    from platform import linux_distribution
except ImportError:
    from lib.distro import linux_distribution


class OSInformation:

    def __init__(self):
        self.os_is_linux = sys.platform.startswith('linux')
        self.os_is_mac = sys.platform.startswith('darwin')
        self.__arch = platform.machine()

        if self.os_is_linux:
            ld = linux_distribution()
            self.os = 'Linux ' + ld[0] + ' ' + ld[1] + ', kernel ' + platform.release()
            self.os_type = 'linux'
        elif self.os_is_mac:
            mac_ver_str = platform.mac_ver()[0]
            self.os = 'OS X ' + mac_ver_str
            ver = mac_ver_str.split('.')
            self.mac_ver = []
            for x in ver:
                self.mac_ver.append(int(x))
            if len(self.mac_ver) < 2:
                self.mac_ver = [10, 11, 0]
            self.os_type = 'osx'
        else:
            self.os = platform.system() + ' ' + platform.version()
            self.os_type = platform.system().lower()

    def is_linux(self):
        return self.os_is_linux

    def is_mac(self):
        return self.os_is_mac

    def mac_version(self):
        return self.mac_ver

    def arch(self):
        return self.__arch

    def get_info(self):
        return {
            'arch': self.__arch,
            'os': self.os,
            'type': self.os_type
        }


os_info = OSInformation()
