import codecs
import sys
from ctypes import *
from ctypes.util import find_library

from lib import os_information

STATUS_OK = 0
STATUS_EMPTY = 1
STATUS_UNRESPONSIVE = 2
STATUS_UNKNOWN = 3


class CardDetector2:
    """Card detection class for python 2"""

    filters = []

    def __init__(self):
        pass

    def append_filter(self, atr, mask, name):
        """Adds new filter to current object"""
        hex_atr = atr.decode('hex')
        hex_mask = mask.decode('hex')
        self.filters.append((map(ord, hex_atr), map(ord, hex_mask), name))

    def find_card_name(self, atr_string):
        """
        Calculates bitwise and on every byte from atr_string to every byte in filter mask,
        and if result is equal to filter atr, returns filter name. Otherwise returns empty string
        """
        for f in self.filters:
            length = len(f[0])
            len_atr = len(atr_string) / 2
            if length != len_atr:
                continue
            found = True
            atr = map(ord, atr_string.decode('hex'))
            for i in range(0, length):
                if atr[i] & f[1][i] != f[0][i]:
                    found = False
                    break
            if found:
                return f[2]
        return ''


class CardDetector3:
    """Card detection class for python 3"""

    filters = []

    def __init__(self):
        pass

    def append_filter(self, atr, mask, name):
        """Adds new filter to current object"""
        hex_atr = codecs.decode(atr, 'hex_codec')
        hex_mask = codecs.decode(mask, 'hex_codec')
        # self.filters.append((map(ord, hex_atr), map(ord, hex_mask), name))
        self.filters.append((hex_atr, hex_mask, name))

    def find_card_name(self, atr_string):
        """
        Calculates bitwise and on every byte from atr_string to every byte in filter mask,
        and if result is equal to filter atr, returns filter name. Otherwise returns empty string
        """
        for f in self.filters:
            length = len(f[0])
            len_atr = len(atr_string) / 2
            if length != len_atr:
                continue
            found = True
            atr = codecs.decode(atr_string, 'hex_codec')
            for i in range(0, length):
                if atr[i] & f[1][i] != f[0][i]:
                    found = False
                    break
            if found:
                return f[2]
        return ''


class SmartCardList:
    found_card_os_card = False
    card_os_atr = '3bf2180002c10a31fe58c80874'
    mapCards = {
        card_os_atr: 'Siemens CardOS V4.3B',
        '3b7f96000080318065b0850300ef120ffe829000': 'Gemalto IDPrime MD 840 (b-trust)',
        '3bf81300008131fe454a434f5076323431b7': 'Charismathics JCOP 2.4.1 (b-trust/stampit)',
        '3bbe9600004105200000000000000000009000': 'CryptoMate64 token (stampit)',
        '3bdb960080b1fe451f830031c064c7fc100001900074': 'Oberthur Cosmo (stampit)',
        '3BFF1300008131FE4D8025A00000005657444B3333300600D2': 'SafeNet DCOS 330U',
        '3bff1800ff8131fe55006b0209020001010144534410318092': 'Bit4id DSD',
        '3bff1800ff8131fe55006b02090200010101434e5310318092': 'Bit4id FFS'
    }
    if sys.version_info[0] < 3:
        card_detector = CardDetector2()
    else:
        card_detector = CardDetector3()
    found_cards = []
    errors = []

    def __init__(self):
        self.card_detector.append_filter('3bff1800ff8131fe55006b02090300010001434e5300318000',
                                         'ffffffffffffffffffffffffffff00ff00ffffffff00ffff00',
                                         'Bit4id DS2048 (L)')
        self.card_detector.append_filter('3bff0000008131fe55006b02090000010001434e5300318000',
                                         'ffff00ff00ffffffffffffffff0000ff00ffffffff00ffff00',
                                         'Bit4id JS2048 (L)')
        self.card_detector.append_filter('3bff1800ff8131fe55006b02090200010001434e5300318000',
                                         'ffffffffffffffffffffffffffffffff00ffffffff00ffff00',
                                         'Bit4id CNS')
        self.card_detector.append_filter('3bff0000008131fe55006b0209000001000144534400318000',
                                         'ffff00ff00ffffffffffffffff0000ff00ffffffff00ffff00',
                                         'Bit4id JS 2048/DSD')

        self.card_detector.append_filter('3b9f958131fe9f006646530500000071df000000000000',
                                         'ffffffffffffffffffffffff000000ffffffffffffff00',
                                         'Feitian ePass2003')

        self.card_detector.append_filter('3bff0000008131004380318065b000000000120ffe82900000',
                                         'ffff00ffffffff00ffffffffffff00000000ffffffffffff00',
                                         'Gemalto IDPrime MD')
        self.card_detector.append_filter('3b7f00000080318065b000000000120ffe829000',
                                         'ffff00ffffffffffffff00000000ffffffffffff',
                                         'Gemalto IDPrime MD')

        if os_information.os_info.is_mac():
            lib_path = find_library('PCSC')
        else:
            lib_path = find_library('pcsclite')
        try:
            scard = LibraryLoader(CDLL).LoadLibrary(lib_path)
        except OSError as ex:
            self.errors.append('Can\'t connect to SmartCard service: ' + str(ex))
            return

        try:
            SCardEstablishContext = scard.SCardEstablishContext
            SCardEstablishContext.restype = c_long
            SCardEstablishContext.argtypes = [c_uint32, c_void_p, c_void_p, POINTER(c_long)]
            SCardReleaseContext = scard.SCardReleaseContext
            SCardReleaseContext.restype = c_long
            SCardReleaseContext.argtypes = [c_long]
            SCardListReaders = scard.SCardListReaders
            SCardListReaders.restype = c_long
            SCardListReaders.argtypes = [c_long, c_char_p, c_char_p, POINTER(c_uint32)]
            SCardConnect = scard.SCardConnect
            SCardConnect.restype = c_long
            SCardConnect.argtypes = [c_long, c_char_p, c_uint32, c_uint32, POINTER(c_long), POINTER(c_uint32)]
            SCardStatus = scard.SCardStatus
            SCardStatus.restype = c_long
            SCardStatus.argtypes = [c_long, c_char_p, POINTER(c_uint32), POINTER(c_uint32), POINTER(c_uint32), c_char_p,
                                    POINTER(c_uint32)]
            SCardDisconnect = scard.SCardDisconnect
            SCardDisconnect.restype = c_long
            SCardDisconnect.argtypes = [c_long, c_uint32]
        except AttributeError as ex:
            self.errors.append('Can\'t connect to SmartCard service: ' + str(ex))
            return

        self.errors = []
        self.found_cards = []
        hctx = c_long(0)
        hresult = SCardEstablishContext(0, None, None, byref(hctx))
        if hresult != 0:
            self.errors.append('SmartCard service not available: ' + hex(hresult))
            return
        try:
            length = c_uint32(0)
            hresult = SCardListReaders(hctx, None, None, byref(length))
            if hresult != 0:
                self.errors.append('Can\'t list readers: ' + hex(hresult))
                return
            arr = create_string_buffer(length.value)
            hresult = SCardListReaders(hctx, None, arr, byref(length))
            if hresult != 0:
                self.errors.append('Can\'t list readers: ' + hex(hresult))
                return
            readers = arr.raw.split(b'\0')
            size = len(arr)
            card = c_long(0)
            protocol = c_uint32(0)

            for reader in readers:
                if len(reader) == 0:
                    continue
                hresult = SCardConnect(hctx, c_char_p(reader), 2, 3, byref(card), byref(protocol))
                atr_string = ''
                if hresult == 0:
                    status = STATUS_OK
                    atr_string = ''
                    tmp = create_string_buffer(size)
                    tmp_len = c_uint32(size)
                    state = c_uint32(0)
                    proto = c_uint32(0)
                    atr = create_string_buffer(32)
                    atr_len = c_uint32(len(atr))
                    hresult = SCardStatus(card, tmp, byref(tmp_len), byref(state), byref(proto), atr, byref(atr_len))
                    if hresult == 0:
                        for i in range(0, atr_len.value):
                            ri = atr.raw[i]
                            if type(ri) is int:
                                ori = ri
                            else:
                                ori = ord(ri)
                            atr_string += format(ori, '02x')
                    SCardDisconnect(card, 2)
                else:
                    if hresult == 0x8010000C:  # no smart card
                        status = STATUS_EMPTY
                    elif hresult == 0x80100066 or hresult == 0x80100067:  # unresponsive or unpowered card
                        status = STATUS_UNRESPONSIVE
                    else:
                        status = STATUS_UNKNOWN

                card_name = ''
                if status == STATUS_OK:
                    card_name = self.get_card_name(atr_string)
                elif status == STATUS_UNRESPONSIVE:
                    card_name = 'Unresponsive card, probably incorrectly inserted'

                self.found_cards.append({
                    'reader': reader.decode('utf-8'),
                    'atr': atr_string,
                    'name': card_name,
                    'status': status
                })

                if self.card_os_atr == atr_string:
                    self.found_card_os_card = True
        finally:
            SCardReleaseContext(hctx)

    def is_card_os_card_found(self):
        return self.found_card_os_card

    def get_card_name(self, atr_string):
        """
        Search for ATR in list of known cards
        :param atr_string: ATR string of searched card
        :return: string containing known card name or atr if atr is not known
        """
        name = self.mapCards.get(atr_string)
        if name is None:
            name = self.card_detector.find_card_name(atr_string)

        return name

    def get_smart_cards(self):
        return self.found_cards, self.errors
