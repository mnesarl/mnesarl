# coding=utf-8
from __future__ import print_function

import os
import sys

from lib import report_generator, gui_utils
from lib.program_info import program_info


class ConsoleGUI:
    def __init__(self):
        self.report_generator = report_generator.ReportGenerator()

    @staticmethod
    def is_available():
        return sys.stdout.isatty()

    @staticmethod
    def query_yes_no(question, default='yes'):
        """Ask a yes/no question via raw_input() and return their answer.

        "question" is a string that is presented to the user.
        "default" is the presumed answer if the user just hits <Enter>.
            It must be "yes" (the default), "no" or None (meaning
            an answer is required of the user).

        The "answer" return value is True for "yes" or False for "no".
        """
        valid = {'yes': True, 'y': True, 'ye': True, 'да': True, 'д': True,
                 'no': False, 'n': False, 'не': False, 'н': False}
        if default is None:
            prompt = ' [y/n] '
        elif default == 'yes':
            prompt = ' [Y/n] '
        elif default == 'no':
            prompt = ' [y/N] '
        else:
            raise ValueError('invalid default answer: "%s"' % default)

        while True:
            sys.stdout.write(question + prompt)
            choice = gui_utils.portable_raw_input().lower()
            if default is not None and choice == '':
                return valid[default]
            elif choice in valid:
                return valid[choice]
            else:
                sys.stdout.write('Please respond with "yes" or "no" (or "y" or "n").\n')

    def save_report(self, prompt, report):
        if not self.query_yes_no(prompt):
            return False, ''
        default_path = os.path.join(os.path.expanduser('~'), gui_utils.report_file)
        while True:
            print('Моля въведете път до файл / Please enter file path [{0}]:'.
                  format(default_path))
            file_path = gui_utils.portable_raw_input()
            if file_path == '':
                file_path = default_path
            if gui_utils.save_to_file(file_path, report):
                return True, file_path
            else:
                message = 'Неуспешен запис във "{0}", желаете ли да въведете различен път? / ' \
                          'Saving to "{0}" failed, do you want to try different file path?'
                if not self.query_yes_no(message.format(file_path)):
                    return False, ''
                default_path = ''

    def run(self):
        print(gui_utils.program_name, 'стартира в конзолен режим.',
              'Моля инсталирайте python-tk (tkinter) или zenity за графичен интефейс.')
        print(gui_utils.program_name, 'was started in console mode.',
              'Please install python-tk (tkinter) or zenity for graphical interface.')
        print('\n')
        print('Моля изчакайте, докато се събира диагностична информация...')
        print('Please wait, while diagnostic information is collected...')
        print(gui_utils.program_name + ', version', program_info['version'])
        self.report_generator.collect_data()
        txt = self.report_generator.text_report()
        print('\n\n--------------------------------------------------------------------------------\n')
        print(txt)
        print('--------------------------------------------------------------------------------\n')

        # Send
        send_canceled = False
        if self.query_yes_no('Изпращане към Инфонотари? / Send to InfoNotary?'):
            si = self.report_generator.json_report()
            resp = gui_utils.ajax_post(si)
            print()
            if resp['ok']:
                message = 'Докладът беше приет успешно. Номер на доклад: {0}\n' \
                          'Report accepted. Your report ID is: {0}'
                print(message.format(gui_utils.pretty_id(resp['id'])))
                return
        else:
            send_canceled = True

        # Save
        if not send_canceled:
            message = 'Неуспешно изпращане. Да се запише ли докладът във файл? / ' \
                      'Sending failed. Do you want to save the report?'
            saved, file_path = self.save_report(message, txt)
            if saved:
                message = 'Докладът беше записан в "{0}", моля изпратете го на {1}\n' \
                          'Report was saved to "{0}" please send it to {1}'
                print(message.format(file_path, 'support@infonotary.com'))
        else:
            message = 'Да се запише ли докладът във файл? / Do you want to save the report?'
            saved, file_path = self.save_report(message, txt)
            if saved:
                message = 'Докладът беше успешно записан в "{0}"\nReport was successfully saved to "{0}"'
                print(message.format(file_path))
