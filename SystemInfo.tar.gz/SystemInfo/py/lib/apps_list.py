# coding=utf-8
import os
import plistlib
import re
import ctypes

from lib import command_runner, exe_finder, firefox_config, installed_sw_mac
from lib.program_info import program_info
from lib.os_information import os_info


class SoftwareList:
    opensc_installed = False
    opensc_card_objects = None
    opensc_version_info = None
    software_list = None
    status_callback = None

    def __init__(self, check_opensc_card_objects, status_callback=None):
        self.check_opensc_card_objects = check_opensc_card_objects
        self.set_status_callback(status_callback)

    def set_status_callback(self, callback):
        if callable(callback):
            self.status_callback = callback

    def notify(self, status):
        if self.status_callback is not None:
            self.status_callback(status)

    def get_software_info(self):
        software_list = []
        self.notify(['Търсене на драйвери за четци...', 'Searching for reader drivers...'])
        software_list.append(('Reader drivers', self.find_reader_drivers()))
        self.notify(['Търсене на PKCS#11 библиотеки...', 'Searching for PKCS#11 libraries...'])
        software_list.append(('PKCS#11 libraries', self.find_pkcs11_libs()))
        self.notify(['Търсене на инсталиран софтуер...', 'Searching for installed software...'])
        software_list.append(('InfoNotary software', self.find_inotary_sw()))
        software_list.append(('Installed browsers', self.find_installed_browsers()))
        if os_info.is_mac():
            software_list.append(('Installed smart card drivers',
                                  installed_sw_mac.find_installed_mw_mac('/var/db/receipts')))

        self.notify(['Четене на настройките на Firefox...', 'Reading Firefox settings...'])
        ff = firefox_config.FirefoxConfig()
        if ff.is_firefox_found():
            software_list.append(('Firefox extensions', ff.get_extensions()))
            software_list.append(('Firefox extensions (system)', ff.get_extensions_system()))
            software_list.append(('Firefox PKCS#11 modules', ff.get_pkcs11_modules()))
        if ff.is_dev_edition_found():
            software_list.append(('Firefox Developer Edition extensions', ff.get_extensions(True)))
            software_list.append(('Firefox Developer Edition extensions (system)', ff.get_extensions_system(True)))
            software_list.append(('Firefox Developer Edition PKCS#11 modules', ff.get_pkcs11_modules(True)))

        if os_info.is_mac():
            self.notify(['Търсене на TokenD модули...', 'Searching for TokenD modules...'])
            software_list.append(('TokenD modules', self.find_tokend_modules()))
        if self.opensc_installed:
            self.notify(['Четене на настройките на OpenSC...', 'Reading OpenSC settings...'])
            opensc = []
            if self.opensc_version_info is not None:
                opensc.append(self.opensc_version_info)
            if self.check_opensc_card_objects:
                if self.opensc_card_objects:
                    opensc.append(('OpenSC card objects', self.opensc_card_objects[1]))
                else:
                    opensc.append(('OpenSC card objects', 'OK'))
            opensc_settings = self.check_opensc_config()
            if opensc_settings['bit4id-disabled']:
                opensc.append(('OpenSC configuration', 'Bit4id cards are disabled in OpenSC'))
            else:
                opensc.append(('OpenSC configuration', 'OK'))
            opensc.append(('OpenSC send/receive size', opensc_settings['send'] + '/' + opensc_settings['recv']))
            software_list.append(('OpenSC information', opensc))

        problem_files = self.find_problem_files()
        if len(problem_files) > 0:
            software_list.append(('Problem files', problem_files))
        software_list.append(('pcscd version', [('pcsc', self.pcscd_version())]))
        software_list.append(('Running smart card services', self.list_running_pcscd()))
        software_list.append(('InfoNotary System Report', [('Version', program_info['version'])]))
        return software_list

    @staticmethod
    def find_installed_browsers():
        result = []
        if os_info.is_mac():
            mac_browsers = [
                ('Firefox', '/Applications/Firefox.app/Contents/Info.plist'),
                ('Google Chrome', '/Applications/Google Chrome.app/Contents/Info.plist'),
                ('Opera', '/Applications/Opera.app/Contents/Info.plist'),
                ('Safari', '/Applications/Safari.app/Contents/Info.plist')
            ]

            for x in mac_browsers:
                if os.path.isfile(x[1]):
                    result.append(get_bundle_info(x[1], x[0]))
        else:
            unix_browsers = [
                ('Firefox', '/usr/bin/firefox', '--version', 'Mozilla Firefox (.+)'),
                ('Google Chrome', '/usr/bin/google-chrome', '--version', 'Google Chrome (.+)'),
                ('Chromium', '/usr/bin/chromium-browser', '--version', 'Chromium ([\d\.]+)'),
                ('Opera', '/usr/bin/opera', '--version', '(.+)'),
                ('Midori', '/usr/bin/midori', '--version', 'Midori ([\d\.]+)'),
                ('GNOME Web', '/usr/bin/epiphany-browser', '--version', 'Web ([\d\.]+)'),
                ('Konqueror', '/usr/bin/konqueror', '--version', 'Konqueror: ([\d\.]+)')
            ]

            for x in unix_browsers:
                if os.path.isfile(x[1]):
                    exe = command_runner.Command([x[1], x[2]])
                    status = exe.run(10)
                    version = None
                    if status == 0:
                        m = re.search(x[3], exe.out)
                        if m:
                            version = m.group(1)
                    if version is None:
                        version = '-'
                    result.append((x[0], version))
        return result

    @staticmethod
    def find_inotary_sw():
        result = []
        if os_info.is_mac():
            mac_sw = [
                ('InfoNotary Smart Card Manager', '/Applications/scardmanager.app/Contents/Info.plist'),
                ('InfoNotary Smart Card Manager', '/Applications/Smart Card Manager.app/Contents/Info.plist'),
                ('InfoNotary e-Doc Signer', '/Applications/e-Doc Signer.app/Contents/Info.plist')
            ]

            for x in mac_sw:
                if os.path.isfile(x[1]):
                    result.append(get_bundle_info(x[1], x[0]))
        else:
            unix_sw = [
                ('InfoNotary Smart Card Manager', '/usr/bin/scardmanager'),
                ('InfoNotary e-Doc Signer', '/usr/bin/insigner')
            ]

            for x in unix_sw:
                if os.path.isfile(x[1]):
                    result.append((x[0], '-'))
        return result

    @staticmethod
    def find_usb_drop_dir():
        exe_path = exe_finder.which('pcscd', ['/usr/sbin/', '/usr/local/bin', '/usr/local/sbin'])
        if exe_path is not None:
            exe = command_runner.Command([exe_path, '--version'])
            if exe.run(10) == 0:
                txt = exe.out
                search_term = 'usbdropdir='
                idx = txt.find(search_term)
                if idx > -1:
                    start = idx + len(search_term)

                    return txt[start:start]
        return None

    def find_reader_drivers(self):
        driver_dirs = []
        if os_info.is_mac():
            driver_dirs = ['/usr/libexec/SmartCardServices/drivers']
            if os_info.mac_version()[1] >= 11:  # On El Capitan we must search /usr/local too
                driver_dirs.append('/usr/local/libexec/SmartCardServices/drivers/')
        else:
            if os.path.isdir('/usr/local/pcsc/drivers'):
                driver_dirs.append('/usr/local/pcsc/drivers')
            if os.path.isdir('/usr/local/lib/pcsc/drivers'):
                driver_dirs.append('/usr/local/lib/pcsc/drivers')
            drop_dir = self.find_usb_drop_dir()
            if drop_dir is not None and os.path.isdir(drop_dir):
                driver_dirs.append(drop_dir)
            else:
                if os.path.isdir('/usr/lib64/pcsc/drivers'):  # RedHat
                    driver_dirs.append('/usr/lib64/pcsc/drivers')
                elif os.path.isdir('/usr/lib64/readers'):  # SUSE
                    driver_dirs.append('/usr/lib64/readers')
                elif os.path.isdir('/usr/lib/readers'):  # SUSE
                    driver_dirs.append('/usr/lib/readers')
                elif os.path.isdir('/usr/lib/pcsc/drivers'):
                    driver_dirs.append('/usr/lib/pcsc/drivers')  # Debian
        drivers = []
        for x in driver_dirs:
            try:
                drivers.extend(bundles_in_dir(x, '.bundle'))
            except OSError:
                pass
        return drivers

    @staticmethod
    def find_problem_files():
        files = [
            '/etc/reader.conf',
            '/Library/LaunchDaemons/org.opensc.pcscd.autostart',
            '/Library/LaunchDaemons/org.opensc.pcscd.autostart.plist'
        ]
        result = []
        for f in files:
            if os.path.isfile(f):
                result.append((f, 'found'))
        if os_info.is_mac():
            ccid_lib = '/usr/libexec/SmartCardServices/drivers/ifd-ccid.bundle/Contents/MacOS/libccid.dylib'
            ccid_lib_path = os.path.realpath(ccid_lib)
            if not os.path.isfile(ccid_lib_path):
                result.append((ccid_lib, 'broken'))
        return result

    @staticmethod
    def find_tokend_modules():
        result = []
        dirs = ['/System/Library/Security/tokend']
        if os_info.mac_version()[1] >= 9:  # After 10.9 we must search /Library too
            dirs.append('/Library/Security/tokend')
        for x in dirs:
            try:
                result.extend(bundles_in_dir(x, '.tokend'))
            except OSError:
                pass
        return result

    @staticmethod
    def opensc_card_objects_check():
        exe_path = exe_finder.which('pkcs15-tool', ['/usr/local/bin'])
        if exe_path is None:
            return True, 'unknown, pkcs15-tool not found'
        exe = command_runner.Command([exe_path, '-D'])
        status = exe.run(10)
        if status != 0:
            return False, 'unknown, exit code ' + str(status)
        certs = 0
        keys = 0
        for line in exe.out.split('\n'):
            if line.find('Public RSA Key') > -1:
                keys += 1
            else:
                if line.find('X.509 Certificate') > -1:
                    certs += 1
        if keys == certs:
            if keys == 0:
                return False, 'No certificates or keys found!'
            return True, 'OK'
        if keys > certs:
            return False, 'There is ' + str(keys - certs) + ' public key(s) without certificate'
        return False, 'There is ' + str(certs - keys) + ' certificate(s) without public key'

    @staticmethod
    def opensc_version_check():
        exe_path = exe_finder.which('opensc-tool', ['/usr/local/bin'])
        if exe_path is not None:
            exe = command_runner.Command([exe_path, '-i'])
            if exe.run(10) == 0:
                lines = exe.out.split('\n')
                ver = lines[0].split(' ', 1)
                return ver[0], ver[1]
        return None

    @staticmethod
    def check_pkcs11_lib(path):
        # Python on macOS 10.12 crashes when loading libsiecap11.dylib
        # TODO: extract PKCS#11 check to external program (build with -mmacosx-version-min=10.5).
        # This will allow all libraries to be checked
        if path.endswith('libsiecap11.dylib'):
            return True
        try:
            lib = ctypes.LibraryLoader(ctypes.CDLL).LoadLibrary(path)

            fl = lib.C_GetFunctionList
            fl.restype = ctypes.c_ulong
            fl.argtypes = [ctypes.POINTER(ctypes.c_void_p)]

            param = ctypes.c_void_p(None)
            return fl(param) == 0
        except OSError:
            return False
        except AttributeError:
            return False

    def find_pkcs11_libs(self):
        result = []
        libs = [
            ('Bit4id', '/usr/lib/libbit4ipki.dylib'),
            ('Bit4id', '/usr/local/lib/libbit4ipki.dylib'),
            ('Bit4id', '/usr/lib/libbit4ipki.so'),
            ('Bit4id', '/System/Library/bit4id/cryptoki/libbit4ipki.dylib'),
            ('OpenSC', '/Library/OpenSC/lib/opensc-pkcs11.so'),
            ('OpenSC', '/Library/OpenSC/lib/onepin-opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/x86_64-linux-gnu/opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/x86_64-linux-gnu/onepin-opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/i386-linux-gnu/opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/i386-linux-gnu/onepin-opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib64/opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib64/onepin-opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/opensc-pkcs11.so'),
            ('OpenSC', '/usr/lib/onepin-opensc-pkcs11.so'),
            ('Siemens', '/usr/local/lib/libsiecap11.so'),
            ('Siemens', '/usr/local/lib/libsiecap11.dylib'),
            ('Charismathics', '/Applications/Charismathics/libcmP11.dylib'),
            ('Charismathics', '/usr/lib/libcmP11.so'),
            ('Charismathics', '/usr/lib64/libcmP11.so'),
            ('Cryptovision', '/usr/local/lib/libcvP11.so'),
            ('Cryptovision', '/usr/local/lib64/libcvP11.so'),
            ('Gemalto', '/usr/lib/pkcs11/libidprimepkcs11.so'),
            ('Gemalto', '/usr/lib/pkcs11/libidprimepkcs11.dylib')
        ]
        for f in libs:
            if os.path.isfile(f[1]):
                if self.check_pkcs11_lib(f[1]):
                    result.append(f)
                    if f[0] == 'OpenSC':
                        self.opensc_installed = True
                else:
                    result.append((f[0], '[not usable] ' + f[1]))
        if self.opensc_installed:
            self.opensc_card_objects = self.opensc_card_objects_check()
            self.opensc_version_info = self.opensc_version_check()
        return result

    @staticmethod
    def check_opensc_config():
        result = {'bit4id-disabled': False, 'send': '255', 'recv': '256'}
        conf = '/Library/OpenSC/etc/opensc.conf'
        if not os.path.isfile(conf):
            conf = '/etc/opensc/opensc.conf'
            if not os.path.isfile(conf):
                conf = '/etc/opensc.conf'
                if not os.path.isfile(conf):
                    return result
        with open(conf, 'r') as f:
            # atr = '3b:ff:18:00:ff:81:31:fe:55:00:6b:02:09:03:03:01:11:01:43:4e:53:11:31:80:8c'
            atr = '3b:ff:??:00:??:81:31:fe:55:00:6b:02:09:??:??:01:??:01:4?:??:??:??:31:80:??'
            # atr = 'ff:ff:00:ff:00:ff:ff:ff:ff:ff:ff:ff:ff:00:00:ff:00:ff:f?:??:??:00:ff:ff:00'
            disabled_bit4id = 'card_atr\s+' + atr.replace('?', '[0-9a-f]') +\
                              '\s*\{\s*name\s*=\s*"[\w\W]+";\s*driver\s*=\s*"[\w\W]+";\s*\}'
            send_receive = re.compile('\s+max_(send|recv)_size = (\d*);')
            comment = re.compile('^\s*#')
            clean_conf = ''
            for line in f.read().split('\n'):
                if comment.match(line) or len(line) == 0:
                    continue
                sr = send_receive.search(line)
                if sr:
                    if send_receive.groups > 1:
                        result[sr.group(1)] = sr.group(2)
                clean_conf += line
            if re.search(disabled_bit4id, clean_conf) is not None:
                result['bit4id-disabled'] = True
            return result

    @staticmethod
    def is_mac_yosemite():
        return os_info.is_mac() and os_info.mac_version()[1] >= 10

    def list_running_pcscd(self):
        result = []
        exe = command_runner.Command(['ps', 'axu'])
        status = exe.run(10)
        if status == 0:
            rows = exe.out.split('\n')
            for row in rows[1:]:
                if len(row) == 0:
                    continue
                items = row.split(None, 10)
                if items[-1].find('pcscd') >= 0:
                    cmd = items[-1]
                    if self.is_mac_yosemite():
                        exe_file = cmd.rpartition('/')
                        if exe_file[0] != '':
                            cmd = exe_file[2]
                    result.append((cmd, items[0]))
        return result

    def pcscd_version(self):
        exe_path = exe_finder.which('pcscd', ['/usr/sbin', '/sbin', '/usr/local/sbin', '/usr/local/bin'])
        if exe_path is None:
            if self.is_mac_yosemite():
                return '-'
            else:
                return 'not found'
        exe = command_runner.Command([exe_path, '-v'])
        status = exe.run(10)
        if status == 0:
            m = re.search('version ([\d.]+)\.', exe.out)
            if m is not None and len(m.groups()) > 0:
                return m.group(1)
        return 'unknown'


def bundles_in_dir(directory, sufix):
    result = []
    for x in os.listdir(directory):
        if x.endswith(sufix):
            name, version = get_bundle_info(os.path.join(directory, x, 'Contents/Info.plist'))
            result.append((x, version))
    return result


def get_bundle_info(plist_path, name='-'):
    version = '-'
    try:
        pl = plistlib.readPlist(plist_path)
        if 'CFBundleName' in pl:
            name = pl['CFBundleName']
        if 'CFBundleShortVersionString' in pl:
            version = pl['CFBundleShortVersionString']
        elif 'CFBundleVersion' in pl:
            version = pl['CFBundleVersion']
    except:
        pass
    return name, version
