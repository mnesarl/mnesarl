# coding=utf-8
from lib import apps_list, os_information, smart_card_list, usb_devices, machine_info
from lib.program_info import program_info


class ReportGenerator:

    def __init__(self):
        self.os_info = None
        self.usb_devs = None
        self.sc_list = None
        self.sw_list = None
        self.machine = None
        self.__done = False
        self.status_callback = None
        self.contact_info = None

    def collect_data(self):
        self.notify(['Program version: ' + program_info['version']])
        self.notify(['Събиране на информация за системата...', 'Collecting system information...'])
        self.os_info = os_information.os_info.get_info()

        self.notify(['Търсене на USB устройства...', 'Scanning USB devices...'])
        self.usb_devs = usb_devices.UsbDevices()

        self.notify(['Търсене на смарт карти...', 'Searching for connected smart cards...'])
        self.sc_list = smart_card_list.SmartCardList()

        self.sw_list = apps_list.SoftwareList(self.sc_list.found_card_os_card, self.status_callback).get_software_info()

        self.notify(['Четене на информация за хардуера...', 'Reading Hardware information...'])
        self.machine = machine_info.MachineInfo()
        self.machine.collect_machine_info()

        self.notify(['Подготвя се доклад...', 'Preparing report...'])
        self.__done = True

    def is_done(self):
        return self.__done

    def notify(self, status):
        if self.status_callback is not None:
            self.status_callback(status)

    def set_status_callback(self, callback):
        if callable(callback):
            self.status_callback = callback

    def add_contact_info(self, contact_info):
        self.contact_info = contact_info

    def text_report(self):
        res = ''

        if self.os_info is None:
            return res

        # Machine information
        if self.machine.get_machine_info() is not None:
            res += 'Machine information:\n'
            for i in self.machine.get_machine_info():
                res += '\t' + i[0] + ': ' + i[1] + '\n'

        # OS information
        res += 'OS: ' + self.os_info['os'] + ' (' + self.os_info['arch'] + ')\n'

        # USB devices
        res += 'USB readers:\n'
        usb_readers, usb_others = self.usb_devs.usb_devices_list()
        for d in usb_readers:
            res += '\t' + str(d) + '\n'
        res += 'Other USB devices:\n'
        for d in usb_others:
            res += '\t' + str(d) + '\n'

        # Smart cards
        res += 'Found smart cards:\n'
        smart_cards, errors = self.sc_list.get_smart_cards()
        for sc in smart_cards:
            res += '\t' + str(sc['reader']) + ': '
            if sc['status'] == smart_card_list.STATUS_OK:
                if len(sc['name']) > 0:
                    res += str(sc['name']) + ' (' + sc['atr'] + ')\n'
                else:
                    res += 'Unknown card with ATR ' + sc['atr'] + ')\n'
            elif sc['status'] == smart_card_list.STATUS_EMPTY:
                res += 'Empty\n'
            elif sc['status'] == smart_card_list.STATUS_UNRESPONSIVE:
                res += 'Unresponsive card, probably incorrectly inserted\n'
            else:
                res += 'Card detection error\n'
        if len(errors) > 0:
            res += 'Smart card list errors:\n'
            for e in errors:
                res += '\t' + e + '\n'

        # Installed software
        for cat in self.sw_list:
            res += cat[0] + ':\n'
            for sw in cat[1]:
                if isinstance(sw[0], str):
                    res += '\t' + str(sw[0]) + ': ' + str(sw[1]) + '\n'
                else:
                    res += '\t' + sw[0].encode('utf-8', 'ignore') + ': ' + sw[1].encode('utf-8', 'ignore') + '\n'

        if self.machine.get_system_id():
            res += 'Machine ID: ' + self.machine.get_system_id()

        return res

    @staticmethod
    def sw_list_to_json(name, sw_list):
        lst = []
        for sw in sw_list:
            lst.append({'name': sw[0], 'version': sw[1]})
        return {'title': name, 'list': lst}

    def json_report(self):
        if self.os_info is None:
            return ''

        usb_readers, usb_others = self.usb_devs.usb_devices_list()
        si = {'os': self.os_info, 'usb': {'readers': usb_readers, 'other': usb_others}}

        # Machine info
        if self.machine.get_machine_info():
            si['machine_info'] = self.sw_list_to_json('Machine information', self.machine.get_machine_info())

        # Smart cards
        smart_cards, errors = self.sc_list.get_smart_cards()
        si['smartcards'] = smart_cards
        si['smartcard_errors'] = errors

        # Installed software
        software = []
        for cat in self.sw_list:
            software.append(self.sw_list_to_json(cat[0], cat[1]))
        si['software'] = software

        # Machine id
        if self.machine.get_system_id():
            si['machine_id'] = self.machine.get_system_id()

        if self.contact_info is not None:
            si['contact'] = self.contact_info

        return si
