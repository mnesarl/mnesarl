import os


def which(program, additional_dirs=None):
    """
    Search for executable file in $PATH
    :param additional_dirs: additional directories to search
    :param program: executable file to search for
    :return: full path to executable file or None if not found
    """

    def is_exe(exe_path):
        return os.path.isfile(exe_path) and os.access(exe_path, os.X_OK)

    file_path, file_name = os.path.split(program)
    if file_path:
        if is_exe(program):
            return program
    else:
        paths = os.environ['PATH'].split(os.pathsep)
        if additional_dirs is not None:
            for d in additional_dirs:
                if d not in paths:
                    paths.append(d)
        for path in paths:
            path = path.strip('"')
            exe_file = os.path.join(path, program)
            if is_exe(exe_file):
                return exe_file

    return None
