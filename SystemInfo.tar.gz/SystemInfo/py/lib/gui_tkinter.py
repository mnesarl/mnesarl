# coding=utf-8
import sys
from threading import Thread

from lib import gui_utils, report_generator

try:
    if sys.version_info[0] < 3:
        import Tkinter as tk_main
        import tkFileDialog as tk_file_dialog
        import tkMessageBox as tk_message_box
        tk_available = True
    else:
        import tkinter as tk_main
        import tkinter.filedialog as tk_file_dialog
        import tkinter.messagebox as tk_message_box
        tk_available = True
except ImportError as ex:
    tk_main = None
    tk_file_dialog = None
    tk_message_box = None
    tk_available = False


if tk_available:
    # GUI class
    # class App(tk_main.Tk):
    class TkinterGui(tk_main.Frame):

        def __init__(self):
            if not tk_available:
                return
            root = tk_main.Tk()
            # tk_main.Tk.__init__(self)
            tk_main.Frame.__init__(self, root)
            self.root = root
            self.report_generator = report_generator.ReportGenerator()
            self.report_generator.set_status_callback(self.observer)

            self.root.title(gui_utils.program_name)

            self.tr = {
                'save': tk_main.StringVar(),
                'copy': tk_main.StringVar(),
                'send': tk_main.StringVar(),
                'lang': tk_main.StringVar(),
                'contact': tk_main.StringVar(),
                'name': tk_main.StringVar(),
                'email': tk_main.StringVar(),
                'phone': tk_main.StringVar(),
                'info': tk_main.StringVar(),
                'done': tk_main.StringVar(),
                'bg': False
            }

            self.switch_locale()

            # Toolbar
            self.toolbar = tk_main.Frame()

            self.btn_send = tk_main.Button(name='btnSend',
                                           textvariable=self.tr['send'], borderwidth=1, command=self.on_send)
            self.btn_send.pack(in_=self.toolbar, side='left')
            self.btn_save = tk_main.Button(name='btnSave',
                                           textvariable=self.tr['save'], borderwidth=1, command=self.on_save)
            self.btn_save.pack(in_=self.toolbar, side='left')
            self.btn_copy = tk_main.Button(name='btnCopy',
                                           textvariable=self.tr['copy'], borderwidth=1, command=self.on_copy)
            self.btn_copy.pack(in_=self.toolbar, side='left')
            self.btn_lang = tk_main.Button(name='btnLang',
                                           textvariable=self.tr['lang'], borderwidth=1, command=self.on_switch_lang)
            self.btn_lang.pack(in_=self.toolbar, side='left')

            # Main part of the GUI
            text_frame = tk_main.Frame(borderwidth=1, relief='sunken')
            self.text = tk_main.Text(wrap=tk_main.NONE, background='white', borderwidth=0, highlightthickness=0)
            self.hsb = tk_main.Scrollbar(orient='horizontal', borderwidth=1, command=self.text.xview)
            self.vsb = tk_main.Scrollbar(orient='vertical', borderwidth=1, command=self.text.yview)
            self.text.configure(xscrollcommand=self.hsb.set, yscrollcommand=self.vsb.set)
            self.hsb.pack(in_=text_frame, side='bottom', fill='x', expand=False)
            self.vsb.pack(in_=text_frame, side='right', fill='y', expand=False)
            self.text.pack(in_=text_frame, side='left', fill='both', expand=True)
            self.toolbar.pack(side='top', fill='x')
            text_frame.pack(side='bottom', fill='both', expand=True)
            self.text.config(state='disabled')
            self.pack()

            self.check_worker_thread()
            worker_thread = Thread(target=self.report_generator.collect_data)
            worker_thread.daemon = True
            worker_thread.start()

        def check_worker_thread(self):
            if not self.report_generator.is_done():
                self.after(100, self.check_worker_thread)
            else:
                self.set_content(self.report_generator.text_report())
                self.on_send(True)

        def run(self):
            self.root.mainloop()

        def observer(self, text):
            self.text.config(state='normal')
            self.text.insert(tk_main.INSERT, '\n'.join(text) + '\n\n')
            self.text.config(state='disabled')

        @staticmethod
        def is_available():
            return tk_available

        def get_content(self):
            self.text.tag_add('sel', '1.0', 'end')
            res = self.text.get('1.0', 'end')
            self.text.tag_remove('sel', '1.0', 'end')
            return res

        def set_content(self, content):
            self.text.config(state='normal')
            self.text.delete('1.0', 'end')
            self.text.insert(tk_main.INSERT, content)
            self.text.config(state='disabled')

        # Copy text to clipboard
        def on_copy(self):
            self.text.clipboard_clear()
            self.text.clipboard_append(self.get_content())

        def on_save(self):
            options = {'filetypes': [('text files', '.txt')], 'defaultextension': '.txt',
                       'initialfile': gui_utils.report_file, 'parent': self.root, 'initialdir': '~'}
            file_name = tk_file_dialog.asksaveasfilename(**options)
            if file_name:
                try:
                    f = open(file_name, 'w')
                    f.write(self.get_content())
                    f.close()
                except IOError:
                    pass

        def on_send(self, done_msg=False):
            if done_msg:
                if self.tr['bg']:
                    message = 'Необходимата диагностична информация е събрана. Желаете ли да бъде изпратена към ' \
                              'Инфонотари сега?\n\nМоже да я изпратите и в последствие чрез бутонът „Изпращане“.'
                else:
                    message = 'All diagnostic information is collected. Do you want to send it to InfoNotary now?\n\n' \
                              'You can send it later with button "Send" in toolbar.'
                if not tk_message_box.askyesno(gui_utils.program_name, message):
                    return

            si = self.report_generator.json_report()
            resp = gui_utils.ajax_post(si)
            if resp['ok']:
                if self.tr['bg']:
                    message = 'Докладът беше приет успешно.\nНомер на доклад: {0}.'
                else:
                    message = 'Report accepted.\nYour report ID is: {0}.'
                self.btn_send.config(state='disabled')
                report_id = gui_utils.pretty_id(resp['id'])
                self.root.title(gui_utils.program_name + ' (' + report_id + ')')
                tk_message_box.showinfo(gui_utils.program_name, message.format(report_id))
            else:
                if self.tr['bg']:
                    message = 'Неуспешно изпращане на доклад.\nМоля, запишете го във файл и го изпратете на {0}'
                else:
                    message = 'Sending of report failed\nPlease save it to file and send it to {0}'
                tk_message_box.showerror(gui_utils.program_name, message.format('support@infonotary.com'))

        def on_switch_lang(self):
            self.switch_locale()

        def switch_locale(self):
            if self.tr['bg']:
                self.tr['save'].set(u'Save to file')
                self.tr['copy'].set(u'Copy to clipboard')
                self.tr['send'].set(u'Send')
                self.tr['lang'].set(u'БГ')
                self.tr['contact'].set(u'Contact information (optional)')
                self.tr['name'].set(u'Name')
                self.tr['email'].set(u'E-mail')
                self.tr['phone'].set(u'Phone')
                self.tr['info'].set(u'Additional information')
                self.tr['done'].set(u'All diagnostic information is collected.\n'
                                    u'Do you want to send it to InfoNotary now?\n\n'
                                    u'You can send it later with button "Send" in toolbar.')
                self.tr['bg'] = False
            else:
                self.tr['save'].set(u'Запис във файл')
                self.tr['copy'].set(u'Копиране в клипборд')
                self.tr['send'].set(u'Изпращане')
                self.tr['lang'].set(u'EN')
                self.tr['contact'].set(u'Информация за контакт (незадължителна)')
                self.tr['name'].set(u'Име')
                self.tr['email'].set(u'Е-mail')
                self.tr['phone'].set(u'Телефон')
                self.tr['info'].set(u'Допълнителна информация')
                self.tr['done'].set(u'Необходимата диагностична информация е събрана.\n'
                                    u'Желаете ли да бъде изпратена към Инфонотари сега?\n\n'
                                    u'Може да я изпратите и в по-късно чрез бутонът „Изпращане“.\n')
                self.tr['bg'] = True
else:
    class TkinterGui:
        def __init__(self):
            pass

        @staticmethod
        def is_available():
            return False
