# coding=utf-8
from __future__ import print_function

from subprocess import Popen

from lib import command_runner, gui_utils, report_generator, exe_finder
from lib.program_info import program_info


class ZenityGUI:
    def __init__(self):
        self.zenity_path = exe_finder.which('zenity')
        self.report_generator = report_generator.ReportGenerator()
        self.title = self.format_title(gui_utils.program_name)  # '--title={0}'.format(gui_utils.program_name)

    @staticmethod
    def format_title(title):
        return '--title={0}'.format(title)

    def is_available(self):
        return self.zenity_path is not None

    def run(self):
        print(gui_utils.program_name + ', version', program_info['version'])
        args = [self.zenity_path, self.title, '--progress', '--pulsate', '--no-cancel',
                '--text=Моля изчакайте, докато се събира диагностична информация...\n'
                'Please wait, while diagnostic information is collected...'
                ]
        p = Popen(args)
        self.report_generator.collect_data()
        txt = self.report_generator.text_report()
        p.terminate()
        status, out = self.zenity(['--text-info'], title='Изпращане към Инфонотари? | Send to InfoNotary?',
                                  input_text=txt.encode())
        if status == 0:
            # Send
            resp = gui_utils.ajax_post(self.report_generator.json_report())
            if resp['ok']:
                report_id = '<span size=\'large\' weight=\'bold\'>' + gui_utils.pretty_id(resp['id']) + '</span>'
                self.zenity(['--info', '--text=Докладът беше приет успешно. Номер на доклад: {0}\n'
                                       'Report accepted. Your report ID is: {0}'.format(report_id)])
            else:
                if self.confirm_save(True):
                    self.save_report(txt, True)

        elif status == 1:
            if self.confirm_save(False):
                self.save_report(txt, False)

    def confirm_save(self, send_failed):
        template = '--text={0}Да се запише ли докладът във файл?\n' \
                   '{1}Do you want to save the report?'
        if send_failed:
            message = template.format('<b>Неуспешно изпращане</b>. ', '<b>Sending failed</b>. ')
        else:
            message = template.format('', '')
        return self.zenity(['--question', message])[0] == 0

    def zenity(self, parameters, title=None, input_text=None):
        if title is not None:
            title = self.format_title(title)
        else:
            title = self.title
        args = [self.zenity_path, title]
        args.extend(parameters)
        exe = command_runner.Command(args)
        status = exe.run(input_text=input_text)
        return status, exe.out

    def save_report(self, report, add_email):
        # Save
        while True:
            status, out = self.zenity(['--file-selection', '--save', '--filename={0}'.format(gui_utils.report_file)])
            if status == 0:
                file_path = out.split('\n', 1)[0]
                if gui_utils.save_to_file(file_path, report):
                    if add_email:
                        mail = '<span foreground=blue>support@infonotary.com</span>'
                        args = ['--info',
                                '--text=Докладът е записан в <b>{0}</b>, моля изпратете го на {1}\n'
                                'Report is saved to <b>{0}</b>, please send it to {1}'.format(file_path, mail)]
                    else:
                        args = ['--info', '--text=Докладът е записан в <b>{0}</b>\n'
                                          'Report is saved to <b>{0}</b>'.format(file_path)]
                    self.zenity(args)
                    return
                else:
                    args = ['--question',
                            '--text=Неуспешен запис в <b>{0}</b>, желаете ли да въведете различен път?\n'
                            'Saving to <b>{0}</b> failed, do you want to try different file path?'.format(file_path)]
                    if self.zenity(args)[0] != 0:
                        return
            else:
                return
