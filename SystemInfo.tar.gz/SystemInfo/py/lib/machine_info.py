import hashlib
import os
import re
import requests

from lib import command_runner
from lib.os_information import os_info


class MachineInfo:
    def __init__(self):
        pass

    system_id = None
    machine_info = None

    chassis_types = {
        # '1': 'Other',
        # '2': 'Unknown',
        '3': 'Desktop',
        '4': 'Low Profile Desktop',
        '5': 'Pizza Box',
        '6': 'Mini Tower',
        '7': 'Tower',
        '8': 'Portable',
        '9': 'Laptop',
        '10': 'Notebook',
        '11': 'Hand Held',
        '12': 'Docking Station',
        '13': 'All in One',
        '14': 'Sub Notebook',
        '15': 'Space - Saving',
        '16': 'Lunch Box',
        '17': 'Main System Chassis',
        '18': 'Expansion Chassis',
        '19': 'Sub Chassis',
        '20': 'Bus Expansion Chassis',
        '21': 'Peripheral Chassis',
        '22': 'Storage Chassis',
        '23': 'Rack Mount Chassis',
        '24': 'Sealed - Case PC'
    }

    # self.collect_machine_info()

    @staticmethod
    def get_system_profiler_output(param, result, keys=None):
        cmd = command_runner.Command(['system_profiler', param])
        if cmd.run() == 0:
            for l in cmd.out.split('\n'):
                l = l.strip()
                if len(l) > 0:
                    item = l.split(': ')
                    if len(item) > 1:
                        if keys:
                            if item[0] in keys:
                                result[keys[item[0]]] = item[1]
                        else:
                            result[item[0]] = item[1]

    def get_mac_system_info(self):
        man = u'Manufacturer'
        device = u'Type'
        model = u'Model'
        system_id = u'system_id'
        serial = u'serial'
        info = {man: u'Apple Inc.'}
        if not os_info.is_mac():
            return info
        enabled_keys = {u'Model Identifier': model, u'Hardware UUID': system_id, u'Model Name': device,
                        u'Serial Number (system)': serial}
        self.get_system_profiler_output('SPHardwareDataType', info, enabled_keys)
        if system_id in info:
            self.set_system_id(info[system_id])
            del info[system_id]

        if serial in info:
            tmp = info[serial]
            cut = tmp[8:]
            try:
                # Ask apple for readable model name, and wait for maximum 2 seconds
                resp = requests.get('http://support-sp.apple.com/sp/product?cc=' + cut, timeout=2)
                if resp.ok:
                    m = re.search('<configCode>(.*)</configCode>', resp.text)
                    if m is not None and m.lastindex == 1:
                        tmp = m.group(1)
                        m = re.search('\((.*)\)', tmp)
                        if m is not None and m.lastindex == 1:
                            info[model] = m.group(1)
                        else:
                            info[model] = tmp
            except requests.exceptions.RequestException:
                pass
            del info[serial]
        self.get_system_profiler_output('SPSoftwareDataType', info, enabled_keys)
        result = []
        if device in info:
            result.append((device, info[device]))
        if man in info:
            result.append((man, info[man]))
        if model in info:
            result.append((model, info[model]))
        return result

    def get_linux_system_info(self):
        result = []
        # Try to get machine-id
        machine_id = None
        if os.path.isfile('/var/lib/dbus/machine-id'):
            machine_id = '/var/lib/dbus/machine-id'
        elif os.path.isfile('/etc/machine-id'):
            machine_id = '/etc/machine-id'
        if machine_id is not None:
            try:
                with open(machine_id) as f:
                    self.set_system_id(f.readline().strip())
            except IOError:
                pass
        ct = self.read_file('/sys/class/dmi/id/chassis_type')
        result.append((u'Type', self.chassis_types.get(ct, 'Unknown (desktop)')))
        result.append((u'Manufacturer', self.read_file('/sys/class/dmi/id/sys_vendor')))
        result.append((u'Model', self.read_file('/sys/class/dmi/id/product_name')))
        return result

    @staticmethod
    def read_file(file_name):
        try:
            f = open(file_name, 'r')
        except EnvironmentError:
            pass
        else:
            with f:
                return f.readline().strip()
        return 'Unknown'

    def collect_machine_info(self):
        if os_info.is_mac():
            result = self.get_mac_system_info()
        else:
            result = self.get_linux_system_info()
        if len(result) > 0:
            self.machine_info = result

    def get_machine_info(self):
        return self.machine_info

    def set_system_id(self, uuid):
        if uuid is not None:
            d = hashlib.sha256()
            d.update(uuid.encode())
            self.system_id = d.hexdigest()

    def get_system_id(self):
        return self.system_id
