from lib import command_runner, os_information


def gen_device_name(vendor, product):
    if vendor.lower() == '25dd' and product.lower() == '1101':
        return 'Bit4id miniLector-S'
    return 'Unnamed USB device'


# Parser for list of usb devices on Mac
def process_usb_list_mac(usb_list):
    prod_id = 'Product ID: '
    vend_id = 'Vendor ID: '
    product_found = False
    name = ''
    p_id = ''
    result = []
    lines = [line.strip() for line in usb_list.split("\n")]
    for line in lines:
        p_id_pos = line.find(prod_id)
        v_id_pos = line.find(vend_id)
        if p_id_pos > -1:
            p_id = line[p_id_pos + len(prod_id):]
            product_found = True
        else:
            if (v_id_pos > -1) and product_found:
                pos = v_id_pos + len(vend_id)
                v_id = line[pos:].partition(' ')
                product_found = False
                result.append((name + v_id[2], v_id[0][2:], p_id[2:]))
            else:
                product_found = False
                if line.endswith(':'):
                    name = line.strip()[:-1]
    return result


# Parser for list of usb devices on Linux
def process_usb_list_linux(usb_list):
    result = []
    lines = [line.strip() for line in usb_list.split('\n')]
    for line in lines:
        if len(line) == 0:
            continue
        parts = line.split(' ', 6)
        if parts[5].startswith('1d6b:'):
            continue
        ids = parts[5].split(':')
        if len(parts) < 7:
            dev_name = gen_device_name(ids[0], ids[1])
        else:
            dev_name = parts[6]
        result.append((dev_name, ids[0], ids[1]))
    return result


class UsbDevices:
    # noinspection SpellCheckingInspection
    reader_vendors = [
        '076b',  # OmniKey
        '072f',  # ACS
        '25dd',  # Bit4id
        '0b0c',  # Todos
        '096e',  # Feitian
        '08e6'   # Gemalto
    ]

    int_usb_list = []

    def __init__(self):
        self.int_usb_list = self.search()

    def usb_devices_list(self):
        return self.int_usb_list

    def search(self):
        readers = []
        others = []
        exe = ['lsusb']
        if os_information.os_info.is_mac():
            exe = ['system_profiler', 'SPUSBDataType']
        command = command_runner.Command(exe)
        res = command.run(10)
        if res == 0:
            devices = []
            if os_information.os_info.is_linux():
                devices = process_usb_list_linux(command.out)
            elif os_information.os_info.is_mac():
                devices = process_usb_list_mac(command.out)
            for d in devices:
                item = d[0] + ' (' + d[1] + ':' + d[2] + ')'
                if d[1].lower() in self.reader_vendors:
                    readers.append(item)
                else:
                    others.append(item)
        return readers, others
