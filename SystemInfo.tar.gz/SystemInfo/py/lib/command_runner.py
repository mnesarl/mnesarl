# Command runner class
import subprocess
import threading


# Command runner class
class Command(object):
    def __init__(self, args):
        self.args = args
        self.process = None
        self.out = None
        self.err = None
        self.failed = False

    def run(self, timeout=None, input_text=None, async_exec=False, environment=None):
        """
        Runs external program
        :param timeout: Maximum wait time for synchronous execution (default: 10 sec)
        :param input_text: string to be send to standard input of executed program
        :param async_exec: if program will be executed asynchronously (default: False)
        :param environment: environment for the process
        :return: exit code if async_exec is False, 0 otherwise
        """

        def target():
            try:
                self.process = subprocess.Popen(self.args, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                                stderr=subprocess.PIPE, env=environment)
                out, err = self.process.communicate(input_text)
                if not async_exec:
                    if out is not None:
                        self.out = out.decode('utf-8')
                    if err is not None:
                        self.err = err.decode('utf-8')
            except OSError:
                self.failed = True

        if self.args is None:
            return -255

        thread = threading.Thread(target=target)
        thread.start()

        if not async_exec:
            thread.join(timeout)
            while thread.is_alive():
                if self.process is not None:
                    self.process.terminate()
                thread.join()

        if self.failed:
            return -254
        if async_exec:
            return 0
        if self.process is not None:
            return self.process.returncode
        else:
            return 0

    def async_kill(self):
        if self.process is not None:
            try:
                self.process.terminate()
            except OSError:
                pass
