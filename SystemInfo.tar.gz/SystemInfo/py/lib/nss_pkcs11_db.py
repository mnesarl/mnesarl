import multiprocessing
import os
import sys
from ctypes import *
from ctypes.util import find_library


class NssDatabase:

    def __init__(self, db_dir):
        self.db_dir = db_dir
        self.nspr_path = find_library('nspr4')
        self.nss_path = find_library('nss3')
        self.firefox_install_dir = None
        self.is_mac = sys.platform.startswith('darwin')
        if self.nspr_path is None or self.nss_path is None:
            # Search for firefox install
            if self.is_mac:
                self.firefox_install_dir = self.find_folder('/Applications', 'firefox')
                if self.firefox_install_dir is not None:
                    self.firefox_install_dir = os.path.join(self.firefox_install_dir, 'Contents', 'MacOS')
                    self.nspr_path = None
                    self.nss_path = os.path.join(self.firefox_install_dir, 'libnss3.dylib')
            else:
                self.firefox_install_dir = self.find_folder('/usr/lib64', 'firefox')
                if self.firefox_install_dir is None:
                    self.firefox_install_dir = self.find_folder('/usr/lib', 'firefox')
                if self.firefox_install_dir is not None:
                    self.nspr_path = os.path.join(self.firefox_install_dir, 'libnspr4.so')
                    self.nss_path = os.path.join(self.firefox_install_dir, 'libnss3.so')

    @staticmethod
    def find_folder(directory, prefix):
        for x in os.listdir(directory):
            if x.lower().startswith(prefix):
                return os.path.join(directory, x)
        return None

    @staticmethod
    def find_modules(mod_list, sufix=''):
        result = []
        while mod_list:
            mod = mod_list.contents.module
            p11 = mod.contents
            if not p11.internal:
                if isinstance(p11.name, bytes):
                    result.append((p11.name.decode('utf-8', 'ignore') + sufix, p11.dll_name.decode('utf-8', 'ignore')))
                else:
                    result.append((p11.name + sufix, p11.dll_name))
            mod_list = mod_list.contents.next
        return result

    def get_pkcs11_modules_db(self, out_results=None):
        """
        Search for PKCS#11 modules configured in PKCS#11 database
        :param out_results: optional dict to store results when started in separate process
        :return: tuple with two elements - boolean for success and list of modules found.
        """
        result = []

        class SECMODModule(Structure):
            _fields_ = [('arena', c_void_p),
                        ('internal', c_int),
                        ('loaded', c_int),
                        ('is_fips', c_int),
                        ('dll_name', c_char_p),
                        ('name', c_char_p)]

        class SECMODModuleList(Structure):
            pass
        SECMODModuleList._fields_ = [('next', POINTER(SECMODModuleList)),
                                     ('module', POINTER(SECMODModule))]

        try:
            nss = LibraryLoader(CDLL).LoadLibrary(self.nss_path)
            if not self.is_mac:
                nspr = LibraryLoader(CDLL).LoadLibrary(self.nspr_path)
            else:
                nspr = nss
            nspr_init = nspr.PR_Init
            nspr_init.restype = None
            nspr_init.argtypes = [c_int, c_int, c_uint]
            nss_init = nss.NSS_Init
            nss_init.restype = c_int
            nss_init.argtypes = [c_char_p]
            nss_shutdown = nss.NSS_Shutdown
            nss_shutdown.restype = c_int
            get_module_list = nss.SECMOD_GetDefaultModuleList
            get_module_list.restype = POINTER(SECMODModuleList)
            get_dead_module_list = nss.SECMOD_GetDeadModuleList
            get_dead_module_list.restype = POINTER(SECMODModuleList)
        except (OSError, AttributeError) as ex:
            if out_results is not None:
                out_results['rv'] = (False, [('Unknown', ex)])
            return False, [('Unknown', ex)]

        try:
            nspr_init(0, 0, 0)
            t = self.db_dir
            b = t.encode('utf-8')
            rv = nss_init(b)
            if rv == 0:
                mod_list = get_module_list()
                result.extend(self.find_modules(mod_list))

                mod_list = get_dead_module_list()
                result.extend(self.find_modules(mod_list, ' (not loaded)'))

                nss_shutdown()
            if out_results is not None:
                out_results['rv'] = (True, result)
            return True, result
        except Exception as ex:
            if out_results is not None:
                out_results['rv'] = (False, [('Unknown', ex)])
            return False, [('Unknown', ex)]

    def get_pkcs11_modules_db_mp(self):
        """
        Starts PKCS#11 search in separate process
        :return: result of search
        """
        manager = multiprocessing.Manager()
        subprocess_result = manager.dict()
        p = multiprocessing.Process(target=self.get_pkcs11_modules_db, args=subprocess_result)
        p.start()

        p.join(10)  # Wait 10 seconds for modules search
        if p.is_alive():
            p.terminate()
            p.join()
        if len(subprocess_result) == 0:
            return False, [('Unknown', 'PKCS#11 error')]
        return subprocess_result['rv']