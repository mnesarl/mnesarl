import os
import sys
import inspect
import traceback

import requests

report_file = 'SystemReport.txt'
program_name = u'InfoNotary System Report'


def get_lib_dir():
    return os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))


def ajax_post(si):
    lib_dir = get_lib_dir()
    bundle = os.path.join(os.path.curdir, os.path.join(lib_dir, 'ca-bundle-sysreport.pem'))
    url = 'https://sysreport.infonotary.com/sysreport/report'
    try:
        resp = requests.post(url, verify=bundle, json=si)
        if resp.status_code == requests.codes.ok:
            return resp.json()
    except Exception:
        print(traceback.format_exc())
    return {'ok': False}


def pretty_id(report_id):
    return report_id[:3] + ' ' + report_id[3:6] + ' ' + report_id[6:]


def save_to_file(file_path, txt):
    try:
        f = open(file_path, 'w')
        f.write(txt)
        f.close()
        return True
    except EnvironmentError:
        return False


def portable_raw_input():
    if sys.version_info[0] < 3:
        return raw_input()
    else:
        return input()
